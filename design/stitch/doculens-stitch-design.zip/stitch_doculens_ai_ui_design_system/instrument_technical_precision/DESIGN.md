---
name: Instrument Technical Precision
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0b1c30'
  on-tertiary-container: '#75859d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  surface-elevated: '#FFFFFF'
  text-primary: '#0F172A'
  text-secondary: '#475569'
  text-tertiary: '#94A3B8'
  border-subtle: '#E2E8F0'
  border-strong: '#0F172A'
  status-success: '#10B981'
  status-warning: '#F59E0B'
  status-error: '#EF4444'
  status-neutral: '#94A3B8'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.55'
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  label-mono:
    fontFamily: Space Grotesk
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.08em
  label-code:
    fontFamily: Space Grotesk
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: 0.02em
  caption:
    fontFamily: Hanken Grotesk
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: '1.4'
    letterSpacing: 0.01em
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

### Personality & Tone
The visual narrative is engineered around architectural restraint, unyielding technical utility, and absolute epistemological calm. Rooted in the visual precision of high-reliability software (Linear, Vercel) and analytical instrumentation, the interface eliminates conversational chat tropes, faux-human avatars, glowing AI gradients, and decorative ornamentation. It treats artificial intelligence not as a novelty, but as a verifiable query-retrieval pipeline.

### Emotional Response
The UI evokes quiet authority, rigorous clarity, and operational confidence. Users must feel they are operating an optical instrument or compiler rather than chatting with a bot. Every pixel serves semantic orientation, data grounding, and technical transparency.

### Design Movement: High-Precision Instrument Minimalism
- **Monochrome Foundation:** Stark architectural slate `#0F172A` grounds high-contrast functional elements against clinical, warm-tinted off-white planes.
- **Orthogonal Geometry:** Exact 0px hard corners define panels, inspector trays, code manifests, and citation chips, evoking drafting paper, physical silicon, and terminal interfaces.
- **Structural Integrity:** Separation through hairline 1px mechanical rules rather than diffuse shadows or stacked elevation layers.
- **Typography Contrast:** Structured, geometric Space Grotesk section titles contrast against readable, neutral Hanken Grotesk body copy.

## Colors

### Palette Strategy
The color architecture enforces strict functional discipline. Color is never decorative; it exists exclusively to signal state, verify evidence, or focus user attention.

- **Primary (`#0F172A`):** Deep obsidian slate used for high-contrast typography, active focus anchors, primary terminal actions, and authoritative borders.
- **Secondary (`#2563EB`):** Precision technical cobalt reserved for active citation references, selected query tokens, document anchor targets, and hyper-specific interactive waypoints.
- **Tertiary (`#64748B`):** Muted slate used for pipeline telemetry, latency markers, stage counters, and auxiliary metadata.
- **Neutral (`#F8FAFC`):** The clinical base surface layer. It avoids harsh `#FFFFFF` glare across entire monitor displays, reducing eye fatigue during intensive document analysis.

### Semantic Status
Status indicators are strictly informational and always accompanied by textual or glyph context:
- **`status-success` (`#10B981`):** Verified ground truth, completed pipeline stages, and validated index states.
- **`status-warning` (`#F59E0B`):** Non-fatal rerank fallbacks, confidence thresholds below parity, or OCR degradation warnings.
- **`status-error` (`#EF4444`):** Retrieval failures, document parsing timeouts, or ungrounded generative assertions.
- **`status-neutral` (`#94A3B8`):** Skipped or queued pipeline stages.

## Typography

### Structural Pairings
- **Headlines & Labels (Space Grotesk):** Provides an architectural, mechanical tone. The proportion and structural cuts of Space Grotesk communicate technical exactness in headers, pipeline tags, evidence counters, and inspector summaries.
- **Reading Body (Hanken Grotesk):** Optimised for legibility in dense document passages, multi-paragraph synthesized answers, and contextual metadata. Hanken Grotesk provides neutral, undistracted readability across long sessions.

### Micro-Typographic Conventions
- **Technical Stage Headers:** All pipeline phases (`RETRIEVAL`, `RERANKING`, `VECTOR SEARCH`, `VERIFICATION`) and evidence labels (`EVIDENCE 01 · PAGE 4`) use `label-mono` in uppercase tracking (`+0.08em`).
- **Telemetry Display:** Latency values (e.g., `42 ms`), candidate ratios (`12 / 128 chunks`), and confidence decimals are rendered via `label-code` to ensure visual tabular alignment.
- **Prose Reading:** Sized deliberately at `0.9375rem` (`15px`) or `1.125rem` (`18px`) with generous line-height (`1.55` - `1.6`) to provide clear visual separation between multi-line retrieved answers.

## Layout & Spacing

### Grid Architecture
The system employs a 3-zone asymmetrical workstation layout for complex analysis tasks:
- **Navigation Inspector (Fixed):** 280px left dock for indexed corpus, pipelines, and document trees. Collapsible to an icon rail (56px) on smaller viewports.
- **Central Synthesis Canvas (Fluid):** Central workspace for user query composition, grounded answer generation, and inline citation referencing.
- **Document & Visual Evidence Stage (Split/Variable):** 400px–560px right pane housing rendered PDF viewports, bounding-box overlays, and raw vector chunk logs.

### Responsive Breakpoints & Adaptations
- **Desktop (>= 1280px):** 3-zone layout visible concurrently. Zero modal transitions needed; direct optical comparison between source and generated synthesis.
- **Tablet (768px – 1279px):** 2-zone horizontal split. The Navigation dock shifts to a collapsible off-canvas flyout. Workspace and Document Viewer retain side-by-side priority.
- **Mobile (< 768px):** 1-column linear stacked flow. The Document Inspector and Pipeline Timeline collapse into bottom-sheet overlay drawers triggered via bottom-fixed status chips.

### Spacing Philosophy
A base-8 mathematical progression governs element separation. Layout gaps (`space-lg`, `space-xl`) define macro functional modules, while tight internal padding (`space-xs`, `space-sm`) enforces data density inside telemetry chips, citation badges, and pipeline tracks. Empty space is structural and intentional, avoiding the need for decorative dividers.

## Elevation & Depth

### Flat Orthogonal Elevation
The system rejects blurred skeuomorphic drop shadows, ambient glow hulls, and glassmorphic blurs. Depth is achieved via **tonal planar steps** and **1px mechanical hairline rules**.

### Elevation Stack
1. **Canvas Surface (Base):** `#F8FAFC`. Base background representing the physical desk or drafting board.
2. **Elevated Workplace Panels (Level 1):** `#FFFFFF`. Sharp-edged panels housing reading surfaces, answer text, and document renderers. Separated from base by a solid 1px `#E2E8F0` hairline border.
3. **Focused / Active Overlays (Level 2):** `#FFFFFF`. Dropdown popovers, citation inspector flyouts, and command palettes. Elevated via a 1px solid border in `#0F172A` with a razor-thin, zero-blur structural drop: `box-shadow: 2px 2px 0px 0px #0F172A`.
4. **Modal Viewports & Drawers (Level 3):** `#FFFFFF`. Backdrops feature a solid 40% `#0F172A` flat scrim with zero blur (`backdrop-filter: none`).

### Structural Connectors
Visual pipelines (Query -> Vector Search -> Cross-Encoder -> Synthesized Assertion) are linked by unbroken 1px vertical and horizontal grid lines using `#E2E8F0`, with active nodes marked by `#0F172A` or `#2563EB`.

## Shapes

### Orthogonal Edge Discipline (0px Radius)
Every structural boundary across the design system is set to sharp right angles (`0px`). Curves and radii are avoided. This hard-edge visual philosophy underscores the system's character as a reliable, rigorous scientific instrument.

- **Buttons & Chips:** Crisp rectangular perimeters.
- **Panels & Dialogs:** 90-degree corners with 1px hairline perimeter borders.
- **Form Controls:** Sharp architectural text boxes with high-contrast active borders.
- **Visual Evidence Previews:** Document clipping crops maintain razor 0px boundaries with hairline bounding-box crosshairs.

### Semantic Glyphs
While containers and UI controls are sharp and orthogonal, data states utilize precise micro-glyphs for status identification:
- `●` (Solid Circle) for active or verified nodes.
- `○` (Open Ring) for idle, queued, or pending nodes.
- `✓` (Checkmark) for validated assertions.
- `✕` (Cross) for rejected hallucination or missing document reference.

## Components

### Buttons & Interactive Triggers
- **Primary Button:** `#0F172A` solid background, `#FFFFFF` text, 0px corner radius, uppercase `Space Grotesk` font (`0.75rem`, `0.05em` tracking). Padding: `0.5rem 1rem`. Hover: `#1E293B`. Active: `#000000`.
- **Secondary / Outline:** `#FFFFFF` background, `#0F172A` text, 1px solid `#E2E8F0` border. Hover: border shifts to `#0F172A`.
- **Ghost / Action Trigger:** Pure text trigger with secondary slate color `#475569`, transitioning to `#0F172A` on hover.

### Citation Chips (`[Page X]`)
- Rectangular badge with 0px corner radius.
- Default: `#FFFFFF` background, 1px solid `#E2E8F0`, `#0F172A` text, `0.6875rem` Space Grotesk.
- Hover / Active Target: `#0F172A` background, `#FFFFFF` text, with instantaneous viewport panning in the linked Document Viewer.
- Linked Verified Citation: Prepended with an emerald `●` (`#10B981`) dot indicator.

### Input Fields & Query Terminals
- Background `#FFFFFF`, 1px solid `#CBD5E1` border, 0px radius.
- Padding: `0.75rem 1rem`.
- Focus State: Crisp 1px solid `#0F172A` outer border accompanied by a 1px solid `#0F172A` offset ring (`outline: 1px solid #0F172A; outline-offset: 1px`). No diffuse blue glow rings.

### Pipeline Stage Modules
- Container: `#FFFFFF` surface with 1px hairline `#E2E8F0` border.
- Layout: 2-column tabular item. Left: Upper-case stage descriptor (`RETRIEVAL`, `RERANK`, `VALIDATE`) in `label-mono`. Right: Telemetry data (`42 ms`, `0.94 score`) in tertiary slate `#64748B`.
- State indicator: 8px left border strip indicating running (Cobalt `#2563EB`), success (Emerald `#10B981`), or degraded fallback (Amber `#F59E0B`).

### Document & Evidence Cards
- Structured rectangular cards with `#FFFFFF` background, `#E2E8F0` border.
- Header contains document metadata: filename, timestamp, and page coordinates formatted in `Space Grotesk` uppercase.
- Body displays exact OCR string excerpt with matching keyword highlights in `#DBEAFE` (`border-bottom: 2px solid #2563EB`).
- Hover state: 1px solid `#0F172A` border shift.

### Checkboxes & Radios
- Sharp 14px square inputs (0px radius) with 1px `#CBD5E1` borders.
- Checked state: `#0F172A` solid fill housing a `#FFFFFF` sharp checkmark glyph or center dot.